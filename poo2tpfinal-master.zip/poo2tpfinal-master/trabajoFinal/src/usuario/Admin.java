package usuario;

public class Admin extends Cuenta {
	
	public Admin(String nombre, String mail, String numeroTelefono) {
		super(nombre, mail, numeroTelefono);
	}

	public void obtenerGestionDeCuenta() {
		
	}

}
