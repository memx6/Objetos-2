package interfaces;

public interface HomePagePublisher {
	public void publish(String message);
}
