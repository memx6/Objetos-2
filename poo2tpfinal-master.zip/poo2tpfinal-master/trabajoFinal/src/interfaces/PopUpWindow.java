package interfaces;

public interface PopUpWindow {

	void popUp(String menssage, String color, int fontSize);

}
