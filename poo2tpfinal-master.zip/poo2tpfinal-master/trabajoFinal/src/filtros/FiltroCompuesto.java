package filtros;

public abstract class FiltroCompuesto extends Filtro {
	protected Filtro filtro1;
	protected Filtro filtro2;
}
